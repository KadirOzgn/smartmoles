
import React from 'react';

const WhatSection: React.FC = () => {
  return (
    <section id="what" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-green-700 font-bold tracking-widest uppercase text-sm"></span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4 mb-4 text-gray-900">SmartMole's Akıllı Yönetim Sistemi</h2>
          <p className="text-lg text-gray-500">İşletmenize kazandıracağımız somut değerler.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {/* Proven Savings */}
          <div className="flex flex-col group">
            <div className="relative h-72 rounded-3xl overflow-hidden mb-8 shadow-lg group-hover:shadow-2xl transition-all duration-500">
              <img 
                src="https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80&w=800" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                alt="Proven Savings" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <span className="text-white font-bold text-3xl">%50'ye Varan</span>
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-3 flex items-center gap-2 text-gray-900">
              <span className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-sm">✓</span> 
              Kanıtlanmış Tasarruf
            </h3>
            <p className="text-gray-600 text-lg leading-relaxed">
              İşletme giderlerinizi ve su tüketiminizi <span className="text-green-700 font-bold">oranlarda düşürür.</span> Verimlilik odaklı amortisman planıyla yatırımınız hızla geri döner.
            </p>
          </div>

          {/* Flawless Appearance - UPDATED WITH HIGH QUALITY GOLF COURSE IMAGE */}
          <div className="flex flex-col group">
            <div className="relative h-72 rounded-3xl overflow-hidden mb-8 shadow-lg group-hover:shadow-2xl transition-all duration-500">
              <img 
                src="https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&q=80&w=1000" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                alt="Premium Lush Golf Course Landscape" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <span className="text-white font-bold text-lg text-shadow">Mükemmel Peyzaj</span>
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-3 flex items-center gap-2 text-gray-900">
              <span className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-sm">✓</span> 
              Premium Peyzaj Kalitesi
            </h3>
            <p className="text-gray-600 text-lg leading-relaxed">
              Sararan çimlere son verir. Golf sahalarınızda ve otel bahçenizde peyzaj kalitesini <span className="text-green-700 font-semibold">standardize eder</span>, misafir deneyimini mükemmelleştirir.
            </p>
          </div>

          {/* Sustainability Report */}
          <div className="flex flex-col group">
            <div className="relative h-72 rounded-3xl overflow-hidden mb-8 shadow-lg group-hover:shadow-2xl transition-all duration-500">
              <img 
                src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=800" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                alt="Sustainability Report" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <div className="flex gap-2">
                  <span className="bg-white/20 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded border border-white/30 font-bold">LEED</span>
                  <span className="bg-white/20 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded border border-white/30 font-bold">GREEN KEY</span>
                </div>
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-3 flex items-center gap-2 text-gray-900">
              <span className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-sm">✓</span> 
              Sürdürülebilirlik Raporu
            </h3>
            <p className="text-gray-600 text-lg leading-relaxed">
              Karbon ayak izinizi düşürerek <span className="italic">Leed, BREEAM</span> ve <span className="italic">Green Key</span> gibi sertifikasyon süreçlerinizi verilerle destekler.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatSection;
